==================
pip install fastapi uvicorn pyodbc
==================
Para iniciar o servidor, execute o comando:
uvicorn main:app --reload
==================
Endpoints
Adicionar Dados
Método: POST

URL: /add_data/

Body:

json

{
    "id": 1,
    "rfid": "1234567890",
    "peso": 12.34,
    "preco": 99.99,
    "nome": "Sensor A"
}

==================
Recuperar Dados
Método: GET

URL: /get_data/

Resposta:

json

{
    "data": [
        {
            "id": 1,
            "rfid": "1234567890",
            "peso": 12.34,
            "preco": 99.99,
            "nome": "Sensor A"
        }
    ]
}