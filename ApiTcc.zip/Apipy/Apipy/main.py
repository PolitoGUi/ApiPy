from fastapi import FastAPI
from pydantic import BaseModel
import pyodbc

app = FastAPI()


class SensorData(BaseModel):
    id: int
    rfid: str
    peso: float
    preco: float
    nome: str


def get_db_connection():
    try:
        connection = pyodbc.connect(
            "Driver={SQL Server};"
            r"Server=PC_GUILHERME\SQLEXPRESS04;"
            "Database=test_db;"
        )
        return connection
    except pyodbc.Error as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        return None


def init_db():
    connection = get_db_connection()
    if connection is None:
        print("Conexão com o banco de dados falhou. A inicialização foi cancelada.")
        return

    try:
        cursor = connection.cursor()
        cursor.execute('''
            IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='sensor_data' AND xtype='U')
            CREATE TABLE sensor_data (
                id INT PRIMARY KEY,
                rfid NVARCHAR(255),
                peso FLOAT,
                preco FLOAT,
                nome NVARCHAR(255)
            )
        ''')
        connection.commit()
    except Exception as e:
        print(f"Erro ao criar tabela: {e}")
    finally:
        if connection:
            cursor.close()
            connection.close()


init_db()


@app.post("/add_data/")
async def add_data(data: SensorData):
    connection = get_db_connection()
    if connection is None:
        return {"message": "Erro ao conectar ao banco de dados"}

    try:
        cursor = connection.cursor()
        cursor.execute('''
            INSERT INTO sensor_data (id, rfid, peso, preco, nome)
            VALUES (?, ?, ?, ?, ?)
        ''', (data.id, data.rfid, data.peso, data.preco, data.nome))
        connection.commit()
    except Exception as e:
        print(f"Erro ao inserir dados: {e}")
        return {"message": "Erro ao adicionar dados"}
    finally:
        if connection:
            cursor.close()
            connection.close()
    return {"message": "Data added successfully"}


@app.get("/get_data/")
async def get_data():
    connection = get_db_connection()
    if connection is None:
        return {"message": "Erro ao conectar ao banco de dados"}

    try:
        cursor = connection.cursor()
        cursor.execute('SELECT * FROM sensor_data')
        rows = cursor.fetchall()
        data = [{"id": row[0], "rfid": row[1], "peso": row[2], "preco": row[3], "nome": row[4]} for row in rows]
    except Exception as e:
        print(f"Erro ao buscar dados: {e}")
        return {"message": "Erro ao buscar dados"}
    finally:
        if connection:
            cursor.close()
            connection.close()
    return {"data": data}
