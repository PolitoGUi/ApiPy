#uvicorn main:app --reload
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg2
from psycopg2 import sql

app = FastAPI()

DATABASE_URL = "postgresql://guilherme:JUkHqaT8aWPzhLXLqZ1eKy3kYjqZm1LZ@dpg-cqtaqslds78s739io6ig-a.oregon-postgres.render.com/test_db_cua7"

def connect_to_db():
    try:
        connection = psycopg2.connect(DATABASE_URL)
        return connection
    except Exception as e:
        print("Erro ao conectar ao banco de dados:", e)
        return None

def create_table(connection):
    cursor = connection.cursor()
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sensor_data (
                id SERIAL PRIMARY KEY,
                esp_id VARCHAR(255),
                rfid VARCHAR(255),
                peso FLOAT,
                preco FLOAT,
                nome VARCHAR(255)
            );
        """)
        connection.commit()
    except Exception as e:
        print("Erro ao criar tabela:", e)
        connection.rollback()
    finally:
        cursor.close()

def insert_data(connection, esp_id, rfid, peso, preco, nome):
    cursor = connection.cursor()
    try:
        cursor.execute("""
            INSERT INTO sensor_data (esp_id, rfid, peso, preco, nome)
            VALUES (%s, %s, %s, %s, %s)
        """, (esp_id, rfid, peso, preco, nome))
        connection.commit()
    except Exception as e:
        print("Erro ao inserir dados:", e)
        connection.rollback()
    finally:
        cursor.close()

def query_data(connection):
    cursor = connection.cursor()
    try:
        cursor.execute("SELECT * FROM sensor_data;")
        rows = cursor.fetchall()
        return rows
    except Exception as e:
        print("Erro ao consultar dados:", e)
        return []
    finally:
        cursor.close()

class SensorData(BaseModel):
    esp_id: str
    rfid: str
    peso: float
    preco: float
    nome: str

@app.on_event("startup")
async def startup_event():
    connection = connect_to_db()
    if connection:
        create_table(connection)
        connection.close()

@app.post("/add_sensor_data/")
async def add_sensor_data(data: SensorData):
    connection = connect_to_db()
    if not connection:
        raise HTTPException(status_code=500, detail="Erro ao conectar ao banco de dados")
    try:
        insert_data(connection, data.esp_id, data.rfid, data.peso, data.preco, data.nome)
        return {"message": "Dados inseridos com sucesso"}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Erro ao inserir dados")
    finally:
        connection.close()

@app.get("/get_sensor_data/")
async def get_sensor_data():
    connection = connect_to_db()
    if not connection:
        raise HTTPException(status_code=500, detail="Erro ao conectar ao banco de dados")
    try:
        data = query_data(connection)
        return {"data": data}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Erro ao consultar dados")
    finally:
        connection.close()
