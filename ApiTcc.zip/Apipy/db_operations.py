import psycopg2
from psycopg2 import sql

# Dados de conexão
host = "dpg-cqtaqslds78s739io6ig-a.oregon-postgres.render.com"
port = "5432"
dbname = "test_db_cua7"
user = "guilherme"
password = "JUkHqaT8aWPzhLXLqZ1eKy3kYjqZm1LZ"

def connect_to_db():
    """Conecta ao banco de dados PostgreSQL e retorna a conexão."""
    try:
        connection = psycopg2.connect(
            host=host,
            port=port,
            dbname=dbname,
            user=user,
            password=password
        )
        print("Conectado ao banco de dados.")
        return connection
    except Exception as error:
        print("Erro ao conectar ao banco de dados:", error)
        return None

def create_table(connection):
    """Cria a tabela no banco de dados."""
    try:
        cursor = connection.cursor()
        create_table_query = '''
        CREATE TABLE IF NOT EXISTS sensor_data (
            id SERIAL PRIMARY KEY,
            esp_id VARCHAR(255),
            rfid VARCHAR(255),
            peso FLOAT,
            preco FLOAT,
            nome VARCHAR(255)
        );
        '''
        cursor.execute(create_table_query)
        connection.commit()
        print("Tabela criada com sucesso.")
    except Exception as error:
        print("Erro ao criar tabela:", error)
    finally:
        cursor.close()

def insert_data(connection, esp_id, rfid, peso, preco, nome):
    """Insere dados na tabela sensor_data."""
    try:
        cursor = connection.cursor()
        insert_query = '''
        INSERT INTO sensor_data (esp_id, rfid, peso, preco, nome)
        VALUES (%s, %s, %s, %s, %s);
        '''
        cursor.execute(insert_query, (esp_id, rfid, peso, preco, nome))
        connection.commit()
        print("Dados inseridos com sucesso.")
    except Exception as error:
        print("Erro ao inserir dados:", error)
    finally:
        cursor.close()

def query_data(connection):
    """Consulta e imprime todos os dados da tabela sensor_data."""
    try:
        cursor = connection.cursor()
        select_query = "SELECT * FROM sensor_data;"
        cursor.execute(select_query)
        rows = cursor.fetchall()
        for row in rows:
            print(row)
    except Exception as error:
        print("Erro ao consultar dados:", error)
    finally:
        cursor.close()

def main():
    """Função principal para executar as operações no banco de dados."""
    connection = connect_to_db()
    if connection:
        create_table(connection)
        insert_data(connection, 'ESP32_001', '123456789', 12.5, 35.0, 'Produto A')
        query_data(connection)
        connection.close()

if __name__ == "__main__":
    main()
